# train your model here












#save your model
import joblib
#joblib.dump(aModel, 'sentiment_analysis_model.joblib')