import joblib


from emoji_translate.emoji_translate import Translator
import string   
import wordninja
from textblob import TextBlob

from nltk.corpus import stopwords

stop_words=set(stopwords.words('english'))
from nltk.tokenize import word_tokenize 
from nltk.stem import PorterStemmer
import re
import cleantext



emo = Translator(exact_match_only=False, randomize=True)
ps = PorterStemmer()


def correctText(text) :
    text = text.lower()

    text = re.sub(r'\w+:\/{2}[\d\w-]+(\.[\d\w-]+)*(?:(?:\/[^\s/]*))*', '', text, flags=re.MULTILINE)

    text = cleantext.replace_emails(text, replace_with="")

    text = text.translate(str.maketrans('', '', string.punctuation))

    text = emo.demojify(text)

    textList = wordninja.split(text)

    text = " ".join(textList)
    
    text = TextBlob(text)
    text = text.correct()
    text1=text.string

    textList = wordninja.split(text1)
    text=""
    text_tokens = textList
    for w in text_tokens:
        if w not in stop_words:
            text=text+" "+w

    text_token = word_tokenize(text)
    text=""
    for w in text_token:
        text=text+" "+ps.stem(w)    
    text_token = word_tokenize(text)

    return text_token

def predict(data):
    clf = joblib.load(r'C:\Users\dzmoh\Documents\HackWave\deploy\modele.sav')
    data=correctText(data)
    data=clf.predict(data)

    result=" "
    if data[0]==0 :
        result="negatif 😒"
    if data[0]==1 :
        result="neutre"
    if data[0]==2 :
        result="positif 😁"
    return result