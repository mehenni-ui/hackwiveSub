import streamlit as st
import pandas as pd
import numpy as np
from prediction import predict

st.set_page_config(
        page_title="Detecting Emotions",
)
st.title('Detecting emotions')
input_text = st.text_input('enter text to analyze')


if st.button('Predict'):
    if(input_text!='') :
        st.text(predict(input_text))
    
    